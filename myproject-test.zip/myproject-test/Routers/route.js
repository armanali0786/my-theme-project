const route = require('express').Router();
const controller = require('../Controller/controller');

const { check, validationResult } = require('express-validator')

const isAuth = require('../middleware/is-auth');

route.get('/', controller.getDashboard)

route.get('/dashboard',controller.getDashboard)

route.get('/basicTables', controller.getTables)

route.get('/basicForms',controller.getForms)

route.get('/register',controller.getRegister);

route.post('/register',controller.postRegister);

route.get('/login',controller.getLogin);

route.post('/login',controller.postLogin);




module.exports = route;