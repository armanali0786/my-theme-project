const route = require('express').Router();

const isAuth = require('../middleware/is-auth');

const customerController = require('../Controller/customer');

route.get('/add-customer',customerController.getAddCustomer);

route.post('/add-customer',customerController.postAddCustomer);

route.get('/edit/:id',customerController.getEditCustomer);

route.post('/update/:id', customerController.postUpdateCustomer);

route.get('/cus-delete/:id', customerController.getDeleteCustomer);

route.get('/payment',customerController.getPayment);

route.post('/payment',customerController.postPayment);

route.get('/success',customerController.getSuccess);

route.get('/cancel',customerController.getCancel);

module.exports = route;