const bcrypt = require('bcrypt');
const crypto = require('crypto');


// const bcrypt = require('bcrypt');
// const crypto = require('crypto');
const User = require('../Models/user');
const Service = require('../Models/service');
// const Customer = require('../Models/customer');

const router = require('../Routers/route');





exports.getDashboard = (req, res) => {
    res.render('dashboard', {
        title: "dashboard"
    })
}

exports.getTables = (req, res) => {
User.find()
  .then(user => {
    Service.find()
    .then(service=>{
        res.render('tables/basicTables', {
            path: '/basicTables',
            pageTitle: 'basic Tables',
            users: user,
            services:service
      })
    })
  })
}



exports.getForms = (req, res) => {
    res.render('forms/basicForms', {
        title: 'Forms'
    })
}

exports.getRegister = (req, res) => {

    res.render('auth/register', {
        title: 'Register'
    })
}

exports.postRegister = (req, res, next) => {
    const { role, name, email, phoneno, dob, address, password, ConfirmPassword } = req.body;
    bcrypt
    .hash(password, 12)
    .then(hashedPassword => {
        const user = new User({
          role: role,
          name: name,
          email: email,
          phoneno: phoneno,
          dob: dob,
          address: address,
          password: hashedPassword,
          ConfirmPassword: hashedPassword
        });
        return user.save()
    })
      .then(result => {
        res.redirect('/login');
      })
      .catch(err => {
        console.log(err);
      });
  };



  exports.getLogin = (req, res) => {
    res.render('auth/login', {
        title: 'Login'
    })
}


exports.postLogin = (req, res, next) => {
    const email = req.body.email;
    const password = req.body.password;
    User.findOne({ email: email })
      .then(user => {
        getuser = user
        if (!user) {
          return res.redirect('/login');
        }
        else {
          bcrypt
            .compare(password, user.password)
            .then(doMatch => {
              if (doMatch) {
                res.redirect('/dashboard');
              }
            }).catch(err=>{
                console.log(err);
            })       
        }
    })         
 }

