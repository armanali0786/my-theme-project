const path = require('path');
const cookieParser = require("cookie-parser");
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);
const csrf = require('csurf');
const flash = require('connect-flash');
const {check} =require('express-validator');
const multer = require('multer');
const port = 4500;
const app = express();



const User = require('./Models/user');
const Service = require('./Models/service');
const Admin = require('./Models/user');
const Customer = require('./Models/customer');

const Routes = require('./Routers/route')
const CustomerRoutes = require('./Routers/customer')
const ServiceRoutes = require('./Routers/service')

app.set('view engine', 'ejs');
app.set('views', 'views');

const MONGODB_URI =
  'mongodb://localhost:27017/ProjectDatabase';
   const store = new MongoDBStore({
  uri: MONGODB_URI
});


app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(Routes)
app.use(CustomerRoutes)
app.use(ServiceRoutes)

app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false }
}));

app.use((req, res) => {
    res.send("<h2>404</h2>")
})

app.use((req, res, next) => {
  if (!req.session.user) {
    return next();
  }
  User.findById(req.session.user._id)
    .then(user => {
      if (!user) {
        return next();
      }
      req.user = user;
      next();
    })
    .catch(err => {
      next(new Error(err));
    });
});


  app.use((req, res, next) => {
    res.locals.isAuthenticated = req.session.isLoggedIn;
    next();
  });

  mongoose
  .connect(MONGODB_URI)
  .then(result => {

  })
  .catch(err => {
    console.log(err);
  });


app.listen(port, () => {
  console.log(`App listening on port http://localhost:${port}`)
})
